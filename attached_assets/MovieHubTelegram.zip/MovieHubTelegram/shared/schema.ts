import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const movies = pgTable("movies", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  posterUrl: text("poster_url").notNull(),
  downloadLink: text("download_link").notNull(),
  telegramChannel: text("telegram_channel").notNull(),
  category: text("category").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const admins = pgTable("admins", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  requiredTelegramChannel: text("required_telegram_channel").notNull(),
  botToken: text("bot_token").notNull(),
});

export const insertMovieSchema = createInsertSchema(movies).omit({ 
  id: true,
  createdAt: true 
});

export const insertAdminSchema = createInsertSchema(admins).omit({ 
  id: true 
});

export const insertSettingsSchema = createInsertSchema(settings).omit({ 
  id: true 
});

export type Movie = typeof movies.$inferSelect;
export type InsertMovie = z.infer<typeof insertMovieSchema>;
export type Admin = typeof admins.$inferSelect;
export type InsertAdmin = z.infer<typeof insertAdminSchema>;
export type Settings = typeof settings.$inferSelect;
export type InsertSettings = z.infer<typeof insertSettingsSchema>;
