import { useState } from "react";
import { type Movie } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface TelegramButtonProps {
  movie: Movie;
}

export function TelegramButton({ movie }: TelegramButtonProps) {
  const { toast } = useToast();
  const [isVerifying, setIsVerifying] = useState(false);

  const handleClick = async () => {
    setIsVerifying(true);
    try {
      const res = await apiRequest("POST", "/api/telegram/verify", {});
      const data = await res.json();

      // Open chat with bot
      window.open(`https://t.me/${data.botUsername}`, "_blank");

      toast({
        title: "Chat with our bot",
        description: (
          <div className="space-y-2">
            <p>Please chat with our bot to access the download link.</p>
            <p>
              After verification, you'll need to join our channel:{" "}
              <a 
                href={`https://t.me/${data.channelUsername.replace("@", "")}`}
                target="_blank"
                rel="noopener noreferrer"
                className="font-semibold hover:underline"
              >
                {data.channelUsername}
              </a>
            </p>
          </div>
        ),
      });
    } catch (error: any) {
      const data = error.response?.data;
      toast({
        title: "Verification failed",
        description: data?.details || "Please try again later",
        variant: "destructive",
      });
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <Button 
      onClick={handleClick} 
      disabled={isVerifying}
      size="lg"
      className="w-full sm:w-auto"
    >
      {isVerifying ? "Opening Telegram..." : "Download via Telegram"}
    </Button>
  );
}