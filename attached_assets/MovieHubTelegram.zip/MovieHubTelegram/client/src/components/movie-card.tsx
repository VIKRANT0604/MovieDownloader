import { type Movie } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";

interface MovieCardProps {
  movie: Movie;
}

export function MovieCard({ movie }: MovieCardProps) {
  return (
    <Link href={`/movie/${movie.id}`}>
      <Card className="overflow-hidden cursor-pointer transition-all hover:scale-[1.02]">
        <div className="aspect-[2/3] relative">
          <img 
            src={movie.posterUrl} 
            alt={movie.title}
            className="absolute inset-0 w-full h-full object-cover"
          />
        </div>
        <CardContent className="p-4">
          <h3 className="font-semibold truncate">{movie.title}</h3>
          <p className="text-sm text-muted-foreground">{movie.category}</p>
        </CardContent>
      </Card>
    </Link>
  );
}
