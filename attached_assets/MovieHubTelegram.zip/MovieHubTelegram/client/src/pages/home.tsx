import { useQuery } from "@tanstack/react-query";
import { type Movie } from "@shared/schema";
import MovieGrid from "@/components/movie-grid";

export default function Home() {
  const { data: movies, isLoading } = useQuery<Movie[]>({ 
    queryKey: ["/api/movies"]
  });

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="h-[300px] bg-muted animate-pulse rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6">
        <h1 className="text-4xl font-bold mb-8 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
          Latest Movies
        </h1>
        <MovieGrid movies={movies || []} />
      </div>
    </div>
  );
}
