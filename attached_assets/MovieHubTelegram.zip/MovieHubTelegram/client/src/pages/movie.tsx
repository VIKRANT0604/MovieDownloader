import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { type Movie } from "@shared/schema";
import { TelegramButton } from "@/components/telegram-button";

export default function MoviePage() {
  const { id } = useParams();
  const { data: movie, isLoading } = useQuery<Movie>({ 
    queryKey: [`/api/movies/${id}`]
  });

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 w-1/3 bg-muted rounded" />
          <div className="h-64 bg-muted rounded" />
          <div className="h-20 bg-muted rounded" />
        </div>
      </div>
    );
  }

  if (!movie) return <div>Movie not found</div>;

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <img 
              src={movie.posterUrl} 
              alt={movie.title}
              className="w-full rounded-lg shadow-xl" 
            />
          </div>
          <div className="space-y-6">
            <h1 className="text-4xl font-bold">{movie.title}</h1>
            <p className="text-muted-foreground">{movie.description}</p>
            <div className="inline-block">
              <span className="px-3 py-1 bg-primary/10 text-primary rounded-full">
                {movie.category}
              </span>
            </div>
            <TelegramButton movie={movie} />
          </div>
        </div>
      </div>
    </div>
  );
}
