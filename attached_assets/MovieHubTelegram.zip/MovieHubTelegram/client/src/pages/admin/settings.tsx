import { useQuery, useMutation } from "@tanstack/react-query";
import { type Settings, insertSettingsSchema } from "@shared/schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormField, FormItem, FormLabel, FormControl } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function AdminSettings() {
  const { toast } = useToast();
  const { data: settings } = useQuery<Settings>({ 
    queryKey: ["/api/settings"]
  });

  const form = useForm({
    resolver: zodResolver(insertSettingsSchema),
    values: settings || {
      requiredTelegramChannel: "",
      botToken: "",
    },
  });

  const updateSettings = useMutation({
    mutationFn: async (data: Settings) => {
      const res = await apiRequest("POST", "/api/settings", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({ title: "Settings updated successfully" });
    },
  });

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-bold mb-6">Telegram Settings</h1>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit((data) => updateSettings.mutate(data))} className="space-y-4">
          <FormField
            control={form.control}
            name="requiredTelegramChannel"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Required Channel ID</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="@yourchannel" />
                </FormControl>
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="botToken"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Bot Token</FormLabel>
                <FormControl>
                  <Input {...field} type="password" />
                </FormControl>
              </FormItem>
            )}
          />

          <Button type="submit">Save Settings</Button>
        </form>
      </Form>
    </div>
  );
}
