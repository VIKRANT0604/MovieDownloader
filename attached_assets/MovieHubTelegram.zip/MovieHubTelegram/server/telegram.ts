import TelegramBot from "node-telegram-bot-api";

export class TelegramService {
  private bot: TelegramBot;
  public botUsername: string = '';
  public channelUsername: string;

  constructor(token: string, channelUsername: string) {
    if (!token) {
      throw new Error('Telegram bot token not found');
    }
    this.channelUsername = channelUsername;

    // Use polling in development, webhook in production
    const options = process.env.NODE_ENV === 'production' 
      ? { webHook: { port: process.env.PORT ? parseInt(process.env.PORT) : 5000 } }
      : { polling: true };

    this.bot = new TelegramBot(token, options);
  }

  async initialize() {
    try {
      // Get bot information
      const botInfo = await this.bot.getMe();
      this.botUsername = botInfo.username;
      console.log('Bot info:', botInfo);

      // Set up webhook for production
      if (process.env.NODE_ENV === 'production') {
        const url = process.env.PUBLIC_URL;
        if (!url) {
          throw new Error('PUBLIC_URL environment variable not set');
        }
        await this.bot.setWebHook(`${url}/telegram-webhook`);
        console.log('Webhook set to:', `${url}/telegram-webhook`);
      } else {
        console.log('Bot started polling in development mode');
      }

      // Set up basic bot commands
      this.setupCommands();

      return this;
    } catch (error) {
      console.error('Failed to initialize Telegram bot:', error);
      throw error;
    }
  }

  private setupCommands() {
    // Handle /start command
    this.bot.onText(/\/start/, async (msg) => {
      const chatId = msg.chat.id;
      await this.bot.sendMessage(chatId, 
        `Welcome! To access movie downloads, please:\n\n` +
        `1. Join our channel ${this.channelUsername}\n` +
        `2. Return to the website to continue`
      );
    });

    // Handle /help command
    this.bot.onText(/\/help/, async (msg) => {
      const chatId = msg.chat.id;
      await this.bot.sendMessage(chatId,
        `Need help? Here's what you can do:\n\n` +
        `1. Use /start to get started\n` +
        `2. Join ${this.channelUsername} for access\n` +
        `3. Visit our website for movie downloads`
      );
    });
  }

  // Method to handle webhook updates
  async handleUpdate(update: any) {
    await this.bot.processUpdate(update);
  }

  // Method to get bot instance
  getBot() {
    return this.bot;
  }
}