import { Movie, Admin, Settings, InsertMovie, InsertAdmin, InsertSettings } from "@shared/schema";

export interface IStorage {
  // Movies
  getMovies(): Promise<Movie[]>;
  getMovie(id: number): Promise<Movie | undefined>;
  createMovie(movie: InsertMovie): Promise<Movie>;
  updateMovie(id: number, movie: Partial<InsertMovie>): Promise<Movie | undefined>;
  deleteMovie(id: number): Promise<boolean>;
  
  // Admins
  getAdmin(username: string): Promise<Admin | undefined>;
  createAdmin(admin: InsertAdmin): Promise<Admin>;
  
  // Settings
  getSettings(): Promise<Settings | undefined>;
  updateSettings(settings: InsertSettings): Promise<Settings>;
}

export class MemStorage implements IStorage {
  private movies: Map<number, Movie>;
  private admins: Map<number, Admin>;
  private settings: Settings | undefined;
  private currentMovieId: number;
  private currentAdminId: number;
  private currentSettingsId: number;

  constructor() {
    this.movies = new Map();
    this.admins = new Map();
    this.currentMovieId = 1;
    this.currentAdminId = 1;
    this.currentSettingsId = 1;

    // Add some sample movies
    const sampleMovies = [
      {
        title: "Inception",
        description: "A thief who steals corporate secrets through dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.",
        posterUrl: "https://m.media-amazon.com/images/M/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_.jpg",
        downloadLink: "https://example.com/inception",
        telegramChannel: "@movieChannel",
        category: "Sci-Fi",
      },
      {
        title: "The Dark Knight",
        description: "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice.",
        posterUrl: "https://m.media-amazon.com/images/M/MV5BMTMxNTMwODM0NF5BMl5BanBnXkFtZTcwODAyMTk2Mw@@._V1_.jpg",
        downloadLink: "https://example.com/dark-knight",
        telegramChannel: "@movieChannel",
        category: "Action",
      },
      {
        title: "Pulp Fiction",
        description: "The lives of two mob hitmen, a boxer, a gangster and his wife, and a pair of diner bandits intertwine in four tales of violence and redemption.",
        posterUrl: "https://m.media-amazon.com/images/M/MV5BNGNhMDIzZTUtNTBlZi00MTRlLWFjM2ItYzViMjE3YzI5MjljXkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_.jpg",
        downloadLink: "https://example.com/pulp-fiction",
        telegramChannel: "@movieChannel",
        category: "Crime",
      }
    ];

    sampleMovies.forEach(movie => {
      const id = this.currentMovieId++;
      this.movies.set(id, { ...movie, id, createdAt: new Date() });
    });
  }

  async getMovies(): Promise<Movie[]> {
    return Array.from(this.movies.values());
  }

  async getMovie(id: number): Promise<Movie | undefined> {
    return this.movies.get(id);
  }

  async createMovie(movie: InsertMovie): Promise<Movie> {
    const id = this.currentMovieId++;
    const newMovie = { ...movie, id, createdAt: new Date() };
    this.movies.set(id, newMovie);
    return newMovie;
  }

  async updateMovie(id: number, movie: Partial<InsertMovie>): Promise<Movie | undefined> {
    const existing = this.movies.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...movie };
    this.movies.set(id, updated);
    return updated;
  }

  async deleteMovie(id: number): Promise<boolean> {
    return this.movies.delete(id);
  }

  async getAdmin(username: string): Promise<Admin | undefined> {
    return Array.from(this.admins.values()).find(
      (admin) => admin.username === username
    );
  }

  async createAdmin(admin: InsertAdmin): Promise<Admin> {
    const id = this.currentAdminId++;
    const newAdmin = { ...admin, id };
    this.admins.set(id, newAdmin);
    return newAdmin;
  }

  async getSettings(): Promise<Settings | undefined> {
    return this.settings;
  }

  async updateSettings(settings: InsertSettings): Promise<Settings> {
    const id = this.currentSettingsId;
    this.settings = { ...settings, id };
    return this.settings;
  }
}

export const storage = new MemStorage();