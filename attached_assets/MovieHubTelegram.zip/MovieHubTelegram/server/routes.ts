import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { TelegramService } from "./telegram";
import { insertMovieSchema } from "@shared/schema";
import multer from "multer";
import path from "path";

const REQUIRED_CHANNEL = "@SYNTAX_WORLD";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize Telegram service
  const telegramService = await new TelegramService(
    process.env.TELEGRAM_BOT_TOKEN,
    REQUIRED_CHANNEL
  ).initialize();

  // Movies API routes remain unchanged
  app.get("/api/movies", async (req, res) => {
    const movies = await storage.getMovies();
    res.json(movies);
  });

  app.get("/api/movies/:id", async (req, res) => {
    const movie = await storage.getMovie(Number(req.params.id));
    if (!movie) return res.status(404).json({ message: "Movie not found" });
    res.json(movie);
  });

  app.post("/api/movies", upload.single("poster"), async (req, res) => {
    const parsed = insertMovieSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ errors: parsed.error.errors });
    }

    const movie = await storage.createMovie(parsed.data);
    res.status(201).json(movie);
  });

  app.patch("/api/movies/:id", async (req, res) => {
    const movie = await storage.updateMovie(Number(req.params.id), req.body);
    if (!movie) return res.status(404).json({ message: "Movie not found" });
    res.json(movie);
  });

  app.delete("/api/movies/:id", async (req, res) => {
    const success = await storage.deleteMovie(Number(req.params.id));
    if (!success) return res.status(404).json({ message: "Movie not found" });
    res.status(204).send();
  });

  // Telegram verification endpoint
  app.post("/api/telegram/verify", async (req, res) => {
    try {
      // Return bot username for redirection
      res.json({ 
        botUsername: telegramService.botUsername,
        channelUsername: telegramService.channelUsername
      });
    } catch (error) {
      console.error('Telegram verification error:', error);
      res.status(500).json({ 
        message: "Failed to get bot information",
        details: "Please try again later"
      });
    }
  });

  // Telegram webhook endpoint for production
  app.post('/telegram-webhook', async (req, res) => {
    try {
      await telegramService.handleUpdate(req.body);
      res.sendStatus(200);
    } catch (error) {
      console.error('Error handling webhook update:', error);
      res.sendStatus(500);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}